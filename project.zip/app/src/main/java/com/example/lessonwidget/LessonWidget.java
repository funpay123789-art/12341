package com.example.lessonwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

public class LessonWidget extends AppWidgetProvider {

    static final String ACTION_TICK = "com.example.lessonwidget.TICK";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateAll(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String a = intent.getAction();
        if (ACTION_TICK.equals(a)
                || Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            updateAll(context);
        }
    }

    @Override
    public void onDisabled(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        am.cancel(tickIntent(context));
    }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, LessonWidget.class));
        if (ids.length == 0) return;

        Planner p = Store.load(c);
        long now = System.currentTimeMillis();
        Planner.State s = p.compute(now);

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setImageViewBitmap(R.id.ring, Ring.draw(s.fraction, p.accent));
        v.setTextViewText(R.id.label, s.label);
        v.setTextViewText(R.id.next, s.next);
        v.setTextViewText(R.id.footer, s.footer);
        v.setTextViewText(R.id.caption, s.caption);
        v.setTextColor(R.id.caption, p.accent);
        v.setViewVisibility(R.id.caption, s.caption.isEmpty() ? View.GONE : View.VISIBLE);
        v.setTextViewText(R.id.sign, (p.wtext.isEmpty() ? "" : p.wtext + " · ") + "made by sqdnikx");
        v.setTextColor(R.id.sign, p.accent);

        if (s.target > 0) {
            v.setViewVisibility(R.id.timer, View.VISIBLE);
            v.setViewVisibility(R.id.center, View.GONE);
            long base = SystemClock.elapsedRealtime() + (s.target - now);
            v.setChronometerCountDown(R.id.timer, true);
            v.setChronometer(R.id.timer, base, null, true);
        } else {
            v.setViewVisibility(R.id.timer, View.GONE);
            v.setViewVisibility(R.id.center, View.VISIBLE);
            v.setTextViewText(R.id.center, s.center);
        }

        PendingIntent open = PendingIntent.getActivity(c, 1,
                new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.root, open);
        m.updateAppWidget(ids, v);

        scheduleNext(c, s.tickAt);
    }

    private static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, LessonWidget.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void scheduleNext(Context c, long at) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = tickIntent(c);
        long t = at + 300;
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
        }
    }
}
