package com.example.lessonwidget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;

/** Рисует кольцо-таймер для виджета. fraction = сколько осталось (1 = полное кольцо). */
public final class Ring {
    private Ring() {}

    public static Bitmap draw(float fraction, int accent) {
        final int size = 240;
        final float stroke = 22f;
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        RectF r = new RectF(stroke, stroke, size - stroke, size - stroke);

        Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(0x26FFFFFF);
        c.drawArc(r, 0f, 360f, false, track);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setShader(new SweepGradient(size / 2f, size / 2f, new int[]{0xFFFF4FD8, accent}, null));
        c.save();
        c.rotate(-90f, size / 2f, size / 2f);
        float f = Math.max(0.02f, Math.min(1f, fraction));
        c.drawArc(r, 0f, 360f * f, false, p);
        c.restore();
        return b;
    }
}
