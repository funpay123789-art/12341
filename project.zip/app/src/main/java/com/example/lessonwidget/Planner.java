package com.example.lessonwidget;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Все данные журнала и вся логика «что сейчас». Без Android, поэтому легко проверять. */
public final class Planner {

    public final Map<Integer, List<Data.Lesson>> week = new HashMap<>();
    public final List<Data.Period> breaks = new ArrayList<>();
    public final List<Data.Holiday> holidays = new ArrayList<>();
    public final Map<String, Data.Entry> entries = new HashMap<>();   // "день|idУрока"
    public final List<Data.Task> tasks = new ArrayList<>();
    public int accent = 0xFFC6FF3D;
    public String wtext = "";

    public static final int LESSON = 0, RECESS = 1, BEFORE = 2, DONE = 3, BREAK = 4, HOLIDAY = 5, FREE = 6;

    public static final class State {
        public int kind;
        public String label = "", caption = "", next = "", center = "", footer = "";
        public long target = -1;   // до какого момента идёт живой отсчёт
        public long tickAt;        // когда в следующий раз перерисовать
        public float fraction = 1f; // сколько осталось от кольца (1 = полное)
    }

    public List<Data.Lesson> lessonsByDow(int dow) {
        List<Data.Lesson> l = week.get(dow);
        if (l == null) {
            l = new ArrayList<>();
            week.put(dow, l);
        }
        return l;
    }

    public void sortAll() {
        for (List<Data.Lesson> l : week.values()) {
            Collections.sort(l, (a, b) -> a.start - b.start);
        }
        Collections.sort(breaks, (a, b) -> a.from - b.from);
        Collections.sort(holidays, (a, b) -> a.day - b.day);
    }

    public List<Data.Lesson> lessons(int day) { return lessonsByDow(Cal.dow(day)); }

    public Data.Lesson findLesson(String id) {
        for (List<Data.Lesson> l : week.values()) {
            for (Data.Lesson x : l) if (x.id.equals(id)) return x;
        }
        return null;
    }

    public Data.Period breakAt(int day) {
        for (Data.Period p : breaks) if (day >= p.from && day <= p.to) return p;
        return null;
    }

    public Data.Holiday holidayAt(int day) {
        for (Data.Holiday h : holidays) if (h.day == day) return h;
        return null;
    }

    public boolean isSchoolDay(int day) {
        return breakAt(day) == null && holidayAt(day) == null && !lessons(day).isEmpty();
    }

    public int nextSchoolDay(int day) {
        for (int i = 1; i <= 800; i++) if (isSchoolDay(day + i)) return day + i;
        return -1;
    }

    public Data.Period nextBreak(int day) {
        Data.Period best = null;
        for (Data.Period p : breaks) {
            if (p.from > day && (best == null || p.from < best.from)) best = p;
        }
        return best;
    }

    public Data.Entry entry(int day, String lessonId) { return entries.get(day + "|" + lessonId); }

    public boolean attention(int day, Data.Lesson l) {
        Data.Entry e = entry(day, l.id);
        return l.star || (e != null && e.attention);
    }

    public int importantCount(int today) {
        int n = 0;
        for (Map.Entry<String, Data.Entry> me : entries.entrySet()) {
            Data.Entry e = me.getValue();
            if (!e.hwImportant || e.done || e.hw.isEmpty()) continue;
            String k = me.getKey();
            int bar = k.indexOf('|');
            try {
                if (Integer.parseInt(k.substring(0, bar)) >= today) n++;
            } catch (Exception ignored) { }
        }
        for (Data.Task t : tasks) if (!t.done) n++;
        return n;
    }

    private String mark(int day, Data.Lesson l) { return attention(day, l) ? "⚠️ " : ""; }

    private String importantSuffix(int day) {
        int n = importantCount(day);
        return n > 0 ? " · ❗" + n : "";
    }

    private String breakInfo(int day) {
        Data.Period b = breakAt(day);
        if (b != null) return b.name + " до " + Cal.fmt(b.to);
        Data.Period nb = nextBreak(day);
        if (nb == null) return "";
        return nb.name + " через " + (nb.from - day) + " дн.";
    }

    private String nextInfo(int day, int nd) {
        if (nd < 0) return "Дальше — лето 🏖";
        Data.Lesson f = lessons(nd).get(0);
        String when = nd == day + 1 ? "Завтра" : Cal.DOW_SHORT[Cal.dow(nd)] + " " + Cal.fmt(nd);
        return when + " в " + f.startText() + " · " + mark(nd, f) + f.title() + importantSuffix(day);
    }

    private static long nextMinute(long now) { return (now / 60000L + 1) * 60000L; }

    public State compute(long now) {
        State s = new State();
        int day = Cal.today(now);
        long dayStart = Cal.dayStart(day);
        long idleTick = Cal.dayStart(day + 1) + 60000L;
        s.footer = breakInfo(day);

        if (!isSchoolDay(day)) {
            int nd = nextSchoolDay(day);
            s.center = nd < 0 ? "🏖" : String.valueOf(nd - day);
            s.caption = nd < 0 ? "" : "дн. до школы";
            Data.Period b = breakAt(day);
            Data.Holiday h = holidayAt(day);
            if (b != null) {
                s.kind = BREAK;
                s.label = "🌴 " + b.name;
                s.fraction = Math.max(0.04f, (b.to - day + 1f) / (b.to - b.from + 1f));
            } else if (h != null) {
                s.kind = HOLIDAY;
                s.label = "🎉 " + h.name;
            } else {
                s.kind = FREE;
                s.label = lessons(day).isEmpty() ? "😴 Выходной" : "😴 Сегодня уроков нет";
            }
            s.next = nextInfo(day, nd);
            s.tickAt = idleTick;
            return s;
        }

        List<Data.Lesson> ls = lessons(day);
        for (int i = 0; i < ls.size(); i++) {
            Data.Lesson l = ls.get(i);
            long st = dayStart + l.start * 60000L;
            long en = dayStart + l.end * 60000L;
            if (now >= en) continue;
            if (now >= st) {
                s.kind = LESSON;
                s.label = mark(day, l) + l.title();
                s.caption = "до конца урока";
                s.target = en;
                s.fraction = Math.max(0.02f, (en - now) / (float) (en - st));
                s.tickAt = Math.min(en, nextMinute(now));
                if (i + 1 < ls.size()) {
                    Data.Lesson n = ls.get(i + 1);
                    s.next = "Дальше: " + mark(day, n) + n.title() + " · " + n.startText();
                } else {
                    s.next = "Это последний урок" + importantSuffix(day);
                }
            } else {
                long prevEnd = i == 0 ? st - 3600000L : dayStart + ls.get(i - 1).end * 60000L;
                s.kind = i == 0 ? BEFORE : RECESS;
                s.label = i == 0 ? "⏰ Скоро уроки" : "☕ Перемена";
                s.caption = i == 0 ? "до начала" : "до урока";
                s.target = st;
                s.fraction = Math.max(0.02f, Math.min(1f, (st - now) / (float) (st - prevEnd)));
                long hourBefore = st - 3600000L;
                s.tickAt = (i == 0 && now < hourBefore) ? hourBefore : Math.min(st, nextMinute(now));
                s.next = "Урок: " + mark(day, l) + l.title() + " · " + l.startText();
            }
            return s;
        }

        s.kind = DONE;
        s.label = "✅ Уроки закончились";
        s.center = "✓";
        s.next = nextInfo(day, nextSchoolDay(day));
        s.tickAt = idleTick;
        return s;
    }
}
