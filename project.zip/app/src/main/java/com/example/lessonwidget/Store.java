package com.example.lessonwidget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/** Хранение всех данных журнала на телефоне (один JSON в SharedPreferences). */
public final class Store {
    private Store() {}

    public static Planner load(Context c) {
        SharedPreferences sp = c.getSharedPreferences("journal", Context.MODE_PRIVATE);
        String d = sp.getString("data", null);
        Planner p = new Planner();
        if (d != null) {
            try {
                fromJson(d, p);
                p.sortAll();
                return p;
            } catch (Exception e) {
                p = new Planner();
            }
        }
        Defaults.fill(p);
        p.sortAll();
        save(c, p);
        return p;
    }

    public static void save(Context c, Planner p) {
        c.getSharedPreferences("journal", Context.MODE_PRIVATE)
                .edit().putString("data", toJson(p)).apply();
    }

    public static String toJson(Planner p) {
        try {
            JSONObject o = new JSONObject();
            JSONObject w = new JSONObject();
            for (int dow = 1; dow <= 7; dow++) {
                JSONArray a = new JSONArray();
                for (Data.Lesson l : p.lessonsByDow(dow)) {
                    JSONObject j = new JSONObject();
                    j.put("id", l.id);
                    j.put("n", l.num);
                    j.put("t", l.name);
                    j.put("s", l.start);
                    j.put("e", l.end);
                    j.put("x", l.star);
                    a.put(j);
                }
                w.put(String.valueOf(dow), a);
            }
            o.put("week", w);

            JSONArray br = new JSONArray();
            for (Data.Period b : p.breaks) {
                JSONObject j = new JSONObject();
                j.put("n", b.name);
                j.put("f", b.from);
                j.put("t", b.to);
                br.put(j);
            }
            o.put("breaks", br);

            JSONArray ho = new JSONArray();
            for (Data.Holiday h : p.holidays) {
                JSONObject j = new JSONObject();
                j.put("d", h.day);
                j.put("n", h.name);
                ho.put(j);
            }
            o.put("holidays", ho);

            JSONObject en = new JSONObject();
            for (java.util.Map.Entry<String, Data.Entry> me : p.entries.entrySet()) {
                Data.Entry e = me.getValue();
                JSONObject j = new JSONObject();
                j.put("t", e.topic);
                j.put("h", e.hw);
                j.put("o", e.note);
                j.put("i", e.hwImportant);
                j.put("a", e.attention);
                j.put("d", e.done);
                en.put(me.getKey(), j);
            }
            o.put("entries", en);

            JSONArray ta = new JSONArray();
            for (Data.Task t : p.tasks) {
                JSONObject j = new JSONObject();
                j.put("id", t.id);
                j.put("t", t.text);
                j.put("d", t.due);
                j.put("x", t.done);
                ta.put(j);
            }
            o.put("tasks", ta);

            o.put("accent", p.accent);
            o.put("wtext", p.wtext);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static void fromJson(String s, Planner p) throws Exception {
        JSONObject o = new JSONObject(s);
        if (!o.has("week")) throw new Exception("not a journal");
        JSONObject w = o.getJSONObject("week");
        for (int dow = 1; dow <= 7; dow++) {
            JSONArray a = w.optJSONArray(String.valueOf(dow));
            if (a == null) continue;
            for (int i = 0; i < a.length(); i++) {
                JSONObject j = a.getJSONObject(i);
                p.lessonsByDow(dow).add(new Data.Lesson(j.getString("id"), j.optString("n", ""),
                        j.getString("t"), j.getInt("s"), j.getInt("e"), j.optBoolean("x", false)));
            }
        }
        JSONArray br = o.optJSONArray("breaks");
        if (br != null) {
            for (int i = 0; i < br.length(); i++) {
                JSONObject j = br.getJSONObject(i);
                p.breaks.add(new Data.Period(j.getString("n"), j.getInt("f"), j.getInt("t")));
            }
        }
        JSONArray ho = o.optJSONArray("holidays");
        if (ho != null) {
            for (int i = 0; i < ho.length(); i++) {
                JSONObject j = ho.getJSONObject(i);
                p.holidays.add(new Data.Holiday(j.getInt("d"), j.getString("n")));
            }
        }
        JSONObject en = o.optJSONObject("entries");
        if (en != null) {
            Iterator<String> it = en.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject j = en.getJSONObject(k);
                Data.Entry e = new Data.Entry();
                e.topic = j.optString("t", "");
                e.hw = j.optString("h", "");
                e.note = j.optString("o", "");
                e.hwImportant = j.optBoolean("i", false);
                e.attention = j.optBoolean("a", false);
                e.done = j.optBoolean("d", false);
                p.entries.put(k, e);
            }
        }
        JSONArray ta = o.optJSONArray("tasks");
        if (ta != null) {
            for (int i = 0; i < ta.length(); i++) {
                JSONObject j = ta.getJSONObject(i);
                Data.Task t = new Data.Task();
                t.id = j.optString("id", "");
                t.text = j.optString("t", "");
                t.due = j.optInt("d", -1);
                t.done = j.optBoolean("x", false);
                p.tasks.add(t);
            }
        }
        p.accent = o.optInt("accent", 0xFFC6FF3D);
        p.wtext = o.optString("wtext", "");
    }
}
