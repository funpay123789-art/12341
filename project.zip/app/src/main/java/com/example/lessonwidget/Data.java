package com.example.lessonwidget;

import java.util.Locale;

public final class Data {
    private Data() {}

    public static String hm(int m) {
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    /** "8:30" -> минуты от полуночи, или -1 */
    public static int parseHm(String s) {
        String[] p = s.trim().split(":");
        if (p.length != 2) return -1;
        try {
            int h = Integer.parseInt(p[0].trim());
            int m = Integer.parseInt(p[1].trim());
            if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
            return h * 60 + m;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static final class Lesson {
        public String id, num, name;
        public int start, end;
        public boolean star;   // «всегда обращать внимание»

        public Lesson(String id, String num, String name, int start, int end, boolean star) {
            this.id = id; this.num = num; this.name = name;
            this.start = start; this.end = end; this.star = star;
        }

        public String title() { return num.isEmpty() ? name : num + ". " + name; }
        public String startText() { return hm(start); }
        public String endText() { return hm(end); }
    }

    public static final class Period {
        public String name;
        public int from, to;   // включительно, номера дней

        public Period(String name, int from, int to) {
            this.name = name; this.from = from; this.to = to;
        }
    }

    public static final class Holiday {
        public int day;
        public String name;

        public Holiday(int day, String name) {
            this.day = day; this.name = name;
        }
    }

    /** Запись журнала на конкретный урок конкретного дня. */
    public static final class Entry {
        public String topic = "", hw = "", note = "";
        public boolean hwImportant, attention, done;

        public boolean isEmpty() {
            return topic.isEmpty() && hw.isEmpty() && note.isEmpty()
                    && !hwImportant && !attention && !done;
        }

        public Entry copy() {
            Entry e = new Entry();
            e.topic = topic; e.hw = hw; e.note = note;
            e.hwImportant = hwImportant; e.attention = attention; e.done = done;
            return e;
        }
    }

    public static final class Task {
        public String id = "", text = "";
        public int due = -1;   // номер дня или -1
        public boolean done;
    }
}
