package com.example.lessonwidget;

import java.util.Calendar;
import java.util.Locale;

/** Даты как номера дней от 1970-01-01 (без java.time, чтобы работало на старых Android). */
public final class Cal {
    private Cal() {}

    public static final String[] DOW_SHORT = {"", "Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};
    public static final String[] DOW_FULL = {"", "Воскресенье", "Понедельник", "Вторник", "Среда",
            "Четверг", "Пятница", "Суббота"};
    public static final String[] MONTHS = {"", "января", "февраля", "марта", "апреля", "мая", "июня",
            "июля", "августа", "сентября", "октября", "ноября", "декабря"};

    public static int toDay(int y, int m, int d) {
        y -= m <= 2 ? 1 : 0;
        int era = (y >= 0 ? y : y - 399) / 400;
        int yoe = y - era * 400;
        int doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
        int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    /** возвращает {год, месяц, день} */
    public static int[] fromDay(int z) {
        z += 719468;
        int era = (z >= 0 ? z : z - 146096) / 146097;
        int doe = z - era * 146097;
        int yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
        int y = yoe + era * 400;
        int doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        int mp = (5 * doy + 2) / 153;
        int d = doy - (153 * mp + 2) / 5 + 1;
        int m = mp + (mp < 10 ? 3 : -9);
        return new int[]{y + (m <= 2 ? 1 : 0), m, d};
    }

    /** Как в Calendar: 1 = воскресенье ... 7 = суббота */
    public static int dow(int day) {
        return ((day + 4) % 7 + 7) % 7 + 1;
    }

    public static int today(long nowMillis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(nowMillis);
        return toDay(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    public static long dayStart(int day) {
        int[] a = fromDay(day);
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(a[0], a[1] - 1, a[2], 0, 0, 0);
        return c.getTimeInMillis();
    }

    public static String fmt(int day) {
        int[] a = fromDay(day);
        return String.format(Locale.US, "%02d.%02d", a[2], a[1]);
    }

    public static String fmtFull(int day) {
        int[] a = fromDay(day);
        return String.format(Locale.US, "%02d.%02d.%04d", a[2], a[1], a[0]);
    }

    public static String fmtLong(int day) {
        int[] a = fromDay(day);
        return a[2] + " " + MONTHS[a[1]];
    }

    /** "дд.мм.гггг" -> номер дня, или Integer.MIN_VALUE если не получилось */
    public static int parse(String s) {
        try {
            String[] p = s.trim().split("\\.");
            if (p.length != 3) return Integer.MIN_VALUE;
            int d = Integer.parseInt(p[0].trim());
            int m = Integer.parseInt(p[1].trim());
            int y = Integer.parseInt(p[2].trim());
            if (y < 100) y += 2000;
            if (m < 1 || m > 12 || d < 1 || d > 31) return Integer.MIN_VALUE;
            int day = toDay(y, m, d);
            int[] back = fromDay(day);
            if (back[2] != d || back[1] != m) return Integer.MIN_VALUE;
            return day;
        } catch (NumberFormatException e) {
            return Integer.MIN_VALUE;
        }
    }
}
