package com.example.lessonwidget;

import java.util.Calendar;
import java.util.List;

/** Стандартные данные. После первого запуска всё хранится в телефоне и правится в настройках. */
public final class Defaults {
    private Defaults() {}

    private static void day(Planner p, int dow, String[][] rows) {
        List<Data.Lesson> l = p.lessonsByDow(dow);
        l.clear();
        for (int i = 0; i < rows.length; i++) {
            l.add(new Data.Lesson(dow + "-" + i, rows[i][0], rows[i][1],
                    Data.parseHm(rows[i][2]), Data.parseHm(rows[i][3]), false));
        }
    }

    public static void fillWeek(Planner p) {
        day(p, Calendar.MONDAY, new String[][]{
                {"", "Разговоры о важном", "08:30", "09:15"},
                {"1", "Геометрия", "09:25", "10:10"},
                {"2", "Русский язык", "10:25", "11:10"},
                {"3", "История", "11:25", "12:10"},
                {"4", "Английский язык", "12:25", "13:10"},
                {"5", "Литература", "13:25", "14:10"},
                {"6", "Физкультура", "14:25", "15:10"}});
        day(p, Calendar.TUESDAY, new String[][]{
                {"1", "Физика", "08:30", "09:15"},
                {"2", "Биология", "09:25", "10:10"},
                {"3", "ОБЗР", "10:25", "11:10"},
                {"4", "Химия", "11:25", "12:10"},
                {"5", "Литература", "12:25", "13:10"},
                {"6", "Геометрия", "13:25", "14:10"},
                {"7", "Первая помощь", "14:25", "15:10"}});
        day(p, Calendar.WEDNESDAY, new String[][]{
                {"1", "Физика", "08:30", "09:15"},
                {"2", "Русский язык", "09:25", "10:10"},
                {"3", "Химия", "10:25", "11:10"},
                {"4", "Обществознание", "11:25", "12:10"},
                {"5", "Английский язык", "12:25", "13:10"},
                {"6", "Алгебра", "13:25", "14:10"},
                {"7", "Биология", "14:25", "15:10"}});
        day(p, Calendar.THURSDAY, new String[][]{
                {"1", "Биология", "08:30", "09:15"},
                {"2", "История", "09:25", "10:10"},
                {"3", "Обществознание", "10:25", "11:10"},
                {"4", "Химия", "11:25", "12:10"},
                {"", "Россия — мои горизонты", "12:25", "13:10"},
                {"5", "Химия: практикум", "13:25", "14:10"},
                {"6", "География", "14:25", "15:10"},
                {"7", "Физкультура", "15:15", "16:00"}});
        day(p, Calendar.FRIDAY, new String[][]{
                {"1", "Индивидуальный проект", "08:30", "09:15"},
                {"2", "Алгебра", "09:25", "10:10"},
                {"3", "Литература", "10:25", "11:10"},
                {"4", "Английский язык", "11:25", "12:10"},
                {"5", "Вероятность и статистика", "13:00", "13:45"},
                {"6", "Физкультура", "14:00", "14:45"},
                {"7", "Информатика", "14:55", "15:40"}});
        day(p, Calendar.SATURDAY, new String[][]{
                {"", "Я поведу тебя в музей", "10:00", "10:45"}});
        p.lessonsByDow(Calendar.SUNDAY).clear();
    }

    public static void fillBreaks(Planner p) {
        p.breaks.clear();
        p.breaks.add(new Data.Period("Осенние каникулы", Cal.toDay(2026, 10, 23), Cal.toDay(2026, 11, 4)));
        p.breaks.add(new Data.Period("Зимние каникулы", Cal.toDay(2026, 12, 31), Cal.toDay(2027, 1, 10)));
        p.breaks.add(new Data.Period("Весенние каникулы", Cal.toDay(2027, 3, 27), Cal.toDay(2027, 4, 4)));
        p.breaks.add(new Data.Period("Летние каникулы", Cal.toDay(2027, 5, 27), Cal.toDay(2027, 8, 31)));
    }

    public static void fillHolidays(Planner p) {
        p.holidays.clear();
        h(p, 2026, 11, 4, "День народного единства");
        h(p, 2027, 2, 22, "Выходной (перенос)");
        h(p, 2027, 2, 23, "День защитника Отечества");
        h(p, 2027, 3, 6, "Международный женский день");
        h(p, 2027, 3, 8, "Международный женский день");
        h(p, 2027, 3, 18, "День воссоединения Крыма с Россией");
        h(p, 2027, 5, 1, "Праздник Весны и Труда");
        h(p, 2027, 5, 3, "Выходной (перенос с 1 мая)");
        h(p, 2027, 5, 10, "День Победы (перенос)");
    }

    private static void h(Planner p, int y, int m, int d, String name) {
        p.holidays.add(new Data.Holiday(Cal.toDay(y, m, d), name));
    }

    public static void fill(Planner p) {
        fillWeek(p);
        fillBreaks(p);
        fillHolidays(p);
    }
}
