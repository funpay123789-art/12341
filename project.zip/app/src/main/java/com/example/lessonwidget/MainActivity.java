package com.example.lessonwidget;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int BG = 0xFF0B0B10, CARD = 0xFF16161F, CARD2 = 0xFF24242F, TEXT = 0xFFF5F5FA,
            DIM = 0xFF8A8A9A, DARK = 0xFF0B0B10, PINK = 0xFFFF4FD8, RED = 0xFFFF5470;
    static final int[] ACCENTS = {0xFFC6FF3D, 0xFFFF4FD8, 0xFF3DF5FF, 0xFF9B6BFF, 0xFFFF8A3D};

    Planner P;
    int tab = 0, page = 0, selDay, weekOffset = 0, settDow = Calendar.MONDAY;
    FrameLayout host;
    LinearLayout nav;
    ScrollView lastSv;

    // ---------- helpers ----------
    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable rr(int color, float rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rDp));
        return g;
    }

    TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        return t;
    }

    TextView title(String s) {
        TextView t = tv(s, 30, TEXT, true);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        return t;
    }

    LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card(int bg) {
        LinearLayout l = vbox();
        l.setBackground(rr(bg, 20));
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        return l;
    }

    TextView chip(String s, int bg, int fg, View.OnClickListener c) {
        TextView t = tv(s, 14, fg, true);
        t.setBackground(rr(bg, 14));
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setGravity(Gravity.CENTER);
        if (c != null) t.setOnClickListener(c);
        return t;
    }

    TextView section(String s) {
        TextView t = tv(s.toUpperCase(), 13, DIM, true);
        t.setLetterSpacing(0.08f);
        return t;
    }

    EditText input(String hint, String val, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(val);
        e.setTextColor(TEXT);
        e.setHintTextColor(DIM);
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setMinLines(2);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        return e;
    }

    CheckBox check(String s, boolean v) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setChecked(v);
        c.setTextColor(TEXT);
        return c;
    }

    TextView small(String s) {
        TextView t = tv(s, 12, DIM, true);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void form(String ttl, LinearLayout content, final Runnable save, final Runnable del) {
        ScrollView sv = new ScrollView(this);
        content.setPadding(dp(20), dp(4), dp(20), dp(4));
        sv.addView(content);
        AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(ttl).setView(sv).setNegativeButton("Отмена", null);
        if (save != null) b.setPositiveButton("Сохранить", (d, w) -> save.run());
        if (del != null) b.setNeutralButton("Удалить", (d, w) -> del.run());
        b.show();
    }

    void confirm(String msg, final Runnable yes) {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setMessage(msg).setNegativeButton("Нет", null)
                .setPositiveButton("Да", (d, w) -> yes.run()).show();
    }

    void commit() {
        P.sortAll();
        Store.save(this, P);
        LessonWidget.updateAll(this);
        render(true);
    }

    // ---------- lifecycle ----------
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(0xFF12121A);
        selDay = Cal.today(System.currentTimeMillis());

        LinearLayout root = vbox();
        root.setBackgroundColor(BG);
        host = new FrameLayout(this);
        root.addView(host, new LinearLayout.LayoutParams(MP, 0, 1f));
        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(0xFF12121A);
        root.addView(nav, new LinearLayout.LayoutParams(MP, dp(62)));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        P = Store.load(this);
        LessonWidget.updateAll(this);
        render(false);
    }

    @Override
    public void onBackPressed() {
        if (tab == 3 && page != 0) {
            page = 0;
            render(false);
        } else {
            super.onBackPressed();
        }
    }

    // ---------- rendering ----------
    void buildNav() {
        nav.removeAllViews();
        String[] names = {"🏠\nСегодня", "📅\nНеделя", "⭐\nВажное", "⚙️\nНастройки"};
        for (int i = 0; i < 4; i++) {
            final int t = i;
            TextView b = tv(names[i], 11, i == tab ? P.accent : DIM, true);
            b.setGravity(Gravity.CENTER);
            b.setOnClickListener(v -> {
                tab = t;
                page = 0;
                render(false);
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, MP, 1f));
        }
    }

    void render(boolean keepScroll) {
        if (P == null) return;
        int y = (keepScroll && lastSv != null) ? lastSv.getScrollY() : 0;
        host.removeAllViews();
        buildNav();
        final ScrollView sv = new ScrollView(this);
        LinearLayout c = vbox();
        c.setPadding(dp(16), dp(20), dp(16), dp(24));
        sv.addView(c);
        switch (tab) {
            case 0: dayTab(c); break;
            case 1: weekTab(c); break;
            case 2: importantTab(c); break;
            default: settingsTab(c); break;
        }
        TextView sign = tv("made by sqdnikx", 12, P.accent, true);
        sign.setGravity(Gravity.CENTER);
        c.addView(sign, lp(MP, WC, 0, 28, 0, 0));
        host.addView(sv);
        lastSv = sv;
        final int fy = y;
        sv.post(() -> sv.scrollTo(0, fy));
    }

    // ---------- TAB: today / day ----------
    void dayTab(LinearLayout c) {
        final long now = System.currentTimeMillis();
        final int today = Cal.today(now);
        c.addView(title(Cal.DOW_FULL[Cal.dow(selDay)]));
        c.addView(tv(Cal.fmtLong(selDay) + (selDay == today ? " · сегодня" : ""), 14, DIM, false),
                lp(MP, WC, 0, 2, 0, 12));

        LinearLayout nv = hbox();
        nv.addView(chip("◀", CARD2, TEXT, v -> { selDay--; render(false); }), lp(WC, WC, 0, 0, 8, 0));
        nv.addView(chip("Сегодня", P.accent, DARK, v -> { selDay = today; render(false); }), lp(WC, WC, 0, 0, 8, 0));
        nv.addView(chip("▶", CARD2, TEXT, v -> { selDay++; render(false); }), lp(WC, WC, 0, 0, 0, 0));
        c.addView(nv, lp(MP, WC, 0, 0, 0, 14));

        Data.Period b = P.breakAt(selDay);
        Data.Holiday ho = P.holidayAt(selDay);
        if (selDay == today) {
            hero(c, now);
        } else if (b != null) {
            infoCard(c, "🌴 " + b.name, "до " + Cal.fmt(b.to));
        } else if (ho != null) {
            infoCard(c, "🎉 " + ho.name, "Уроков нет");
        } else if (P.lessons(selDay).isEmpty()) {
            infoCard(c, "😴 Выходной", "Уроков нет");
        }

        if (P.isSchoolDay(selDay)) {
            for (Data.Lesson l : P.lessons(selDay)) {
                c.addView(lessonRow(selDay, l), lp(MP, WC, 0, 0, 0, 10));
            }
        }

        Data.Entry dn = P.entry(selDay, "day");
        LinearLayout n = card(CARD);
        n.addView(tv("💬 Заметка дня", 14, DIM, true));
        n.addView(tv(dn == null || dn.note.isEmpty() ? "Нажми, чтобы добавить" : dn.note, 15, TEXT, false));
        n.setOnClickListener(v -> editDayNote(selDay));
        c.addView(n, lp(MP, WC, 0, 4, 0, 0));
    }

    void infoCard(LinearLayout c, String big, String small) {
        LinearLayout k = card(CARD);
        k.addView(tv(big, 20, TEXT, true));
        k.addView(tv(small, 14, DIM, false));
        c.addView(k, lp(MP, WC, 0, 0, 0, 12));
    }

    void hero(LinearLayout c, long now) {
        Planner.State s = P.compute(now);
        LinearLayout h = vbox();
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF2A1650, 0xFF14141C});
        g.setCornerRadius(dp(26));
        h.setBackground(g);
        h.setPadding(dp(18), dp(16), dp(18), dp(16));
        h.addView(tv(s.label, 20, TEXT, true));

        LinearLayout row = hbox();
        if (s.target > 0) {
            Chronometer ch = new Chronometer(this);
            ch.setTextSize(46);
            ch.setTextColor(P.accent);
            ch.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            ch.setCountDown(true);
            ch.setBase(SystemClock.elapsedRealtime() + (s.target - now));
            ch.start();
            row.addView(ch);
        } else {
            TextView big = tv(s.center, 46, P.accent, true);
            big.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            row.addView(big);
        }
        row.addView(tv(s.caption, 14, P.accent, true), lp(WC, WC, 10, 14, 0, 0));
        h.addView(row);
        h.addView(tv(s.next, 14, 0xFFD0D0DC, false), lp(MP, WC, 0, 2, 0, 0));
        if (!s.footer.isEmpty()) h.addView(tv(s.footer, 12, DIM, false), lp(MP, WC, 0, 6, 0, 0));
        c.addView(h, lp(MP, WC, 0, 0, 0, 14));
    }

    View lessonRow(final int day, final Data.Lesson l) {
        Data.Entry e = P.entry(day, l.id);
        boolean att = P.attention(day, l);
        LinearLayout row = hbox();
        row.setBackground(rr(att ? 0xFF2A1A30 : CARD, 20));
        row.setPadding(dp(12), dp(12), dp(14), dp(12));

        TextView num = tv(l.num.isEmpty() ? "•" : l.num, 18, DARK, true);
        num.setGravity(Gravity.CENTER);
        num.setBackground(rr(att ? PINK : P.accent, 14));
        row.addView(num, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout col = vbox();
        col.addView(tv(l.name + (att ? "  ⚠️" : ""), 17, TEXT, true));
        col.addView(tv(l.startText() + " – " + l.endText(), 12, DIM, false));
        if (e != null && !e.topic.isEmpty()) col.addView(tv("📖 " + e.topic, 13, 0xFFD0D0DC, false));
        if (e != null && !e.hw.isEmpty()) {
            String pre = e.done ? "✅ " : e.hwImportant ? "❗ " : "📝 ";
            col.addView(tv(pre + e.hw, 13, (e.hwImportant && !e.done) ? 0xFFFF8FA3 : 0xFFD0D0DC, false));
        }
        if (e != null && !e.note.isEmpty()) col.addView(tv("💬 " + e.note, 12, DIM, false));
        row.addView(col, lp(0, WC, 12, 0, 0, 0));
        ((LinearLayout.LayoutParams) col.getLayoutParams()).weight = 1f;
        row.setOnClickListener(v -> editEntry(day, l));
        return row;
    }

    void editEntry(final int day, final Data.Lesson l) {
        final String key = day + "|" + l.id;
        final Data.Entry old = P.entries.get(key);
        final Data.Entry e = old == null ? new Data.Entry() : old.copy();
        LinearLayout f = vbox();
        final EditText topic = input("Тема урока", e.topic, false);
        final EditText hw = input("Домашнее задание", e.hw, true);
        final EditText note = input("Заметка (что угодно)", e.note, true);
        final CheckBox imp = check("❗ Важное ДЗ", e.hwImportant);
        final CheckBox done = check("✅ ДЗ сделано", e.done);
        final CheckBox att = check("⚠️ Обратить внимание на этот урок", e.attention);
        f.addView(small("Тема")); f.addView(topic);
        f.addView(small("Домашнее задание")); f.addView(hw);
        f.addView(imp); f.addView(done);
        f.addView(small("Заметка")); f.addView(note);
        f.addView(att);
        Runnable del = null;
        if (old != null) del = () -> { P.entries.remove(key); commit(); };
        form(Cal.DOW_SHORT[Cal.dow(day)] + " " + Cal.fmt(day) + " · " + l.title(), f, () -> {
            e.topic = topic.getText().toString().trim();
            e.hw = hw.getText().toString().trim();
            e.note = note.getText().toString().trim();
            e.hwImportant = imp.isChecked();
            e.done = done.isChecked();
            e.attention = att.isChecked();
            if (e.isEmpty()) P.entries.remove(key); else P.entries.put(key, e);
            commit();
        }, del);
    }

    void editDayNote(final int day) {
        final String key = day + "|day";
        Data.Entry old = P.entries.get(key);
        final EditText note = input("Заметка на день", old == null ? "" : old.note, true);
        LinearLayout f = vbox();
        f.addView(note);
        form(Cal.DOW_SHORT[Cal.dow(day)] + " " + Cal.fmt(day) + " · заметка", f, () -> {
            String t = note.getText().toString().trim();
            if (t.isEmpty()) {
                P.entries.remove(key);
            } else {
                Data.Entry e = new Data.Entry();
                e.note = t;
                P.entries.put(key, e);
            }
            commit();
        }, null);
    }

    // ---------- TAB: week ----------
    void weekTab(LinearLayout c) {
        final int today = Cal.today(System.currentTimeMillis());
        final int monday = today - ((Cal.dow(today) + 5) % 7) + weekOffset * 7;
        c.addView(title("Неделя"));
        c.addView(tv(Cal.fmt(monday) + " – " + Cal.fmt(monday + 6), 14, DIM, false), lp(MP, WC, 0, 2, 0, 12));

        LinearLayout nv = hbox();
        nv.addView(chip("◀", CARD2, TEXT, v -> { weekOffset--; render(false); }), lp(WC, WC, 0, 0, 8, 0));
        nv.addView(chip("Эта неделя", P.accent, DARK, v -> { weekOffset = 0; render(false); }), lp(WC, WC, 0, 0, 8, 0));
        nv.addView(chip("▶", CARD2, TEXT, v -> { weekOffset++; render(false); }), lp(WC, WC, 0, 0, 0, 0));
        c.addView(nv, lp(MP, WC, 0, 0, 0, 14));

        for (int i = 0; i < 7; i++) {
            final int d = monday + i;
            Data.Period b = P.breakAt(d);
            Data.Holiday ho = P.holidayAt(d);
            if (i == 6 && P.lessons(d).isEmpty() && b == null && ho == null) continue;
            LinearLayout k = card(d == today ? 0xFF1F1A2E : CARD);
            LinearLayout head = hbox();
            head.addView(tv(Cal.DOW_SHORT[Cal.dow(d)] + " " + Cal.fmt(d), 17, d == today ? P.accent : TEXT, true));
            String st = b != null ? "  🌴 " + b.name : ho != null ? "  🎉 " + ho.name : "";
            head.addView(tv(st, 12, DIM, false));
            k.addView(head);
            if (b == null && ho == null) {
                if (P.lessons(d).isEmpty()) {
                    k.addView(tv("Выходной", 13, DIM, false));
                }
                for (Data.Lesson l : P.lessons(d)) {
                    Data.Entry e = P.entry(d, l.id);
                    String line = l.startText() + "  " + l.title();
                    if (P.attention(d, l)) line += "  ⚠️";
                    if (e != null && !e.hw.isEmpty()) line += e.done ? "  ✅" : e.hwImportant ? "  ❗" : "  📝";
                    k.addView(tv(line, 14, 0xFFD0D0DC, false), lp(MP, WC, 0, 3, 0, 0));
                }
            }
            k.setOnClickListener(v -> { selDay = d; tab = 0; render(false); });
            c.addView(k, lp(MP, WC, 0, 0, 0, 10));
        }
    }

    // ---------- TAB: important ----------
    static final class Item {
        final int day;
        final Data.Lesson lesson;
        final Data.Entry entry;

        Item(int day, Data.Lesson lesson, Data.Entry entry) {
            this.day = day; this.lesson = lesson; this.entry = entry;
        }
    }

    void importantTab(LinearLayout c) {
        final int today = Cal.today(System.currentTimeMillis());
        c.addView(title("Важное"));

        c.addView(section("❗ Важное ДЗ"), lp(MP, WC, 0, 14, 0, 8));
        List<Item> hw = new ArrayList<>();
        for (Map.Entry<String, Data.Entry> me : P.entries.entrySet()) {
            Data.Entry e = me.getValue();
            if (!e.hwImportant || e.done || e.hw.isEmpty()) continue;
            String k = me.getKey();
            int bar = k.indexOf('|');
            try {
                int d = Integer.parseInt(k.substring(0, bar));
                Data.Lesson l = P.findLesson(k.substring(bar + 1));
                if (l != null) hw.add(new Item(d, l, e));
            } catch (Exception ignored) { }
        }
        Collections.sort(hw, (a, b) -> a.day - b.day);
        if (hw.isEmpty()) c.addView(tv("Пока ничего важного 🎉", 14, DIM, false));
        for (Item it : hw) {
            final Item f = it;
            LinearLayout k = card(CARD);
            String late = it.day < today ? "  ⏰ просрочено" : "";
            k.addView(tv(Cal.DOW_SHORT[Cal.dow(it.day)] + " " + Cal.fmt(it.day) + " · " + it.lesson.name + late,
                    13, it.day < today ? RED : P.accent, true));
            k.addView(tv(it.entry.hw, 15, TEXT, false));
            k.setOnClickListener(v -> editEntry(f.day, f.lesson));
            c.addView(k, lp(MP, WC, 0, 0, 0, 8));
        }

        c.addView(section("⚠️ Обратить внимание (3 недели)"), lp(MP, WC, 0, 18, 0, 8));
        int count = 0;
        for (int d = today; d <= today + 21; d++) {
            if (!P.isSchoolDay(d)) continue;
            for (final Data.Lesson l : P.lessons(d)) {
                if (!P.attention(d, l)) continue;
                final int fd = d;
                Data.Entry e = P.entry(d, l.id);
                LinearLayout k = card(0xFF2A1A30);
                k.addView(tv(Cal.DOW_SHORT[Cal.dow(d)] + " " + Cal.fmt(d) + " · " + l.startText(), 13, PINK, true));
                k.addView(tv(l.title(), 15, TEXT, false));
                if (e != null && !e.topic.isEmpty()) k.addView(tv("📖 " + e.topic, 13, DIM, false));
                k.setOnClickListener(v -> editEntry(fd, l));
                c.addView(k, lp(MP, WC, 0, 0, 0, 8));
                count++;
            }
        }
        if (count == 0) c.addView(tv("Отметок нет. Нажми на урок → «Обратить внимание».", 14, DIM, false));

        c.addView(section("✅ Мои задачи"), lp(MP, WC, 0, 18, 0, 8));
        for (final Data.Task t : P.tasks) {
            LinearLayout k = card(CARD);
            String due = t.due >= 0 ? "  · до " + Cal.fmt(t.due) : "";
            k.addView(tv((t.done ? "✅ " : "⬜ ") + t.text + due, 15, t.done ? DIM : TEXT, false));
            k.setOnClickListener(v -> editTask(t));
            c.addView(k, lp(MP, WC, 0, 0, 0, 8));
        }
        c.addView(chip("+ Добавить задачу", P.accent, DARK, v -> editTask(null)), lp(WC, WC, 0, 6, 0, 0));
    }

    void editTask(final Data.Task old) {
        final Data.Task t = old != null ? old : new Data.Task();
        final EditText text = input("Что нужно сделать", t.text, true);
        final EditText due = input("Срок дд.мм.гггг (можно пусто)", t.due >= 0 ? Cal.fmtFull(t.due) : "", false);
        final CheckBox done = check("✅ Сделано", t.done);
        LinearLayout f = vbox();
        f.addView(small("Задача")); f.addView(text);
        f.addView(small("Срок")); f.addView(due);
        f.addView(done);
        Runnable del = null;
        if (old != null) del = () -> { P.tasks.remove(old); commit(); };
        form(old == null ? "Новая задача" : "Задача", f, () -> {
            String s = text.getText().toString().trim();
            if (s.isEmpty()) { toast("Напиши задачу"); return; }
            int d = -1;
            String ds = due.getText().toString().trim();
            if (!ds.isEmpty()) {
                d = Cal.parse(ds);
                if (d == Integer.MIN_VALUE) { toast("Дата: дд.мм.гггг"); return; }
            }
            t.text = s;
            t.due = d;
            t.done = done.isChecked();
            if (old == null) {
                t.id = Long.toHexString(System.nanoTime());
                P.tasks.add(t);
            }
            commit();
        }, del);
    }

    // ---------- TAB: settings ----------
    void settingsTab(LinearLayout c) {
        if (page == 1) { schedulePage(c); return; }
        if (page == 2) { breaksPage(c); return; }
        if (page == 3) { holidaysPage(c); return; }

        c.addView(title("Настройки"));

        c.addView(section("Цвет"), lp(MP, WC, 0, 16, 0, 8));
        LinearLayout sw = hbox();
        for (final int col : ACCENTS) {
            TextView d = tv(col == P.accent ? "✓" : "", 18, DARK, true);
            d.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            d.setBackground(g);
            d.setOnClickListener(v -> { P.accent = col; commit(); });
            sw.addView(d, lp(dp(44), dp(44), 0, 0, 12, 0));
        }
        c.addView(sw);

        c.addView(section("Журнал"), lp(MP, WC, 0, 20, 0, 8));
        menu(c, "🗓  Расписание уроков", "Предметы и время звонков", 1);
        menu(c, "🌴  Каникулы", P.breaks.size() + " периодов", 2);
        menu(c, "🎉  Праздники и выходные", P.holidays.size() + " дней", 3);

        LinearLayout w = card(CARD);
        w.addView(tv("✏️  Надпись на виджете", 16, TEXT, true));
        w.addView(tv(P.wtext.isEmpty() ? "Сейчас: только made by sqdnikx" : "Сейчас: " + P.wtext, 13, DIM, false));
        w.setOnClickListener(v -> {
            final EditText e = input("Твоя надпись (коротко)", P.wtext, false);
            LinearLayout f = vbox();
            f.addView(e);
            form("Надпись на виджете", f, () -> {
                P.wtext = e.getText().toString().trim();
                commit();
            }, null);
        });
        c.addView(w, lp(MP, WC, 0, 0, 0, 10));

        c.addView(section("Резервная копия"), lp(MP, WC, 0, 20, 0, 8));
        LinearLayout bk = hbox();
        bk.addView(chip("Скопировать всё", CARD2, TEXT, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("journal", Store.toJson(P)));
            toast("Скопировано в буфер");
        }), lp(WC, WC, 0, 0, 8, 0));
        bk.addView(chip("Вставить из буфера", CARD2, TEXT, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData cd = cm.getPrimaryClip();
            String s = (cd != null && cd.getItemCount() > 0) ? cd.getItemAt(0).coerceToText(this).toString() : "";
            try {
                Planner n = new Planner();
                Store.fromJson(s, n);
                P = n;
                commit();
                toast("Журнал восстановлен");
            } catch (Exception ex) {
                toast("В буфере нет копии журнала");
            }
        }), lp(WC, WC, 0, 0, 0, 0));
        c.addView(bk);
        c.addView(tv("Копию можно отправить себе в заметки, чтобы не потерять при переустановке.", 12, DIM, false),
                lp(MP, WC, 0, 6, 0, 0));

        c.addView(section("Сброс"), lp(MP, WC, 0, 20, 0, 8));
        LinearLayout rs = hbox();
        rs.addView(chip("Расписание", CARD2, RED, v -> confirm("Вернуть стандартное расписание уроков?", () -> {
            Defaults.fillWeek(P);
            commit();
        })), lp(WC, WC, 0, 0, 8, 0));
        rs.addView(chip("Каникулы и праздники", CARD2, RED, v -> confirm("Вернуть стандартные каникулы и праздники?", () -> {
            Defaults.fillBreaks(P);
            Defaults.fillHolidays(P);
            commit();
        })), lp(WC, WC, 0, 0, 0, 0));
        c.addView(rs);

        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                c.addView(section("Точность виджета"), lp(MP, WC, 0, 20, 0, 8));
                c.addView(tv("Чтобы кольцо и урок менялись ровно со звонком, разреши точные будильники.", 13, DIM, false));
                c.addView(chip("Разрешить", P.accent, DARK, v -> startActivity(new Intent(
                        Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())))), lp(WC, WC, 0, 8, 0, 0));
            }
        }
    }

    void menu(LinearLayout c, String name, String sub, final int target) {
        LinearLayout k = card(CARD);
        k.addView(tv(name, 16, TEXT, true));
        k.addView(tv(sub, 13, DIM, false));
        k.setOnClickListener(v -> { page = target; render(false); });
        c.addView(k, lp(MP, WC, 0, 0, 0, 10));
    }

    void backRow(LinearLayout c, String ttl) {
        c.addView(chip("← Назад", CARD2, TEXT, v -> { page = 0; render(false); }), lp(WC, WC, 0, 0, 0, 12));
        c.addView(title(ttl), lp(MP, WC, 0, 0, 0, 12));
    }

    void schedulePage(LinearLayout c) {
        backRow(c, "Расписание");
        LinearLayout days = hbox();
        int[] order = {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
                Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};
        for (final int dow : order) {
            boolean sel = dow == settDow;
            days.addView(chip(Cal.DOW_SHORT[dow], sel ? P.accent : CARD2, sel ? DARK : TEXT,
                    v -> { settDow = dow; render(false); }), lp(WC, WC, 0, 0, 6, 0));
        }
        c.addView(days, lp(MP, WC, 0, 0, 0, 14));

        for (final Data.Lesson l : P.lessonsByDow(settDow)) {
            LinearLayout k = card(CARD);
            k.addView(tv(l.title() + (l.star ? "  ⚠️" : ""), 16, TEXT, true));
            k.addView(tv(l.startText() + " – " + l.endText(), 13, DIM, false));
            k.setOnClickListener(v -> editLesson(settDow, l));
            c.addView(k, lp(MP, WC, 0, 0, 0, 8));
        }
        c.addView(chip("+ Добавить урок", P.accent, DARK, v -> editLesson(settDow, null)), lp(WC, WC, 0, 6, 0, 0));
    }

    void editLesson(final int dow, final Data.Lesson old) {
        final Data.Lesson l = old != null ? old
                : new Data.Lesson("u" + Long.toHexString(System.nanoTime()), "", "", 510, 555, false);
        final EditText num = input("№ урока (можно пусто)", l.num, false);
        final EditText name = input("Предмет", l.name, false);
        final EditText st = input("Начало, например 08:30", Data.hm(l.start), false);
        final EditText en = input("Конец, например 09:15", Data.hm(l.end), false);
        final CheckBox star = check("⚠️ Всегда обращать внимание на этот урок", l.star);
        LinearLayout f = vbox();
        f.addView(small("Номер")); f.addView(num);
        f.addView(small("Предмет")); f.addView(name);
        f.addView(small("Начало")); f.addView(st);
        f.addView(small("Конец")); f.addView(en);
        f.addView(star);
        Runnable del = null;
        if (old != null) del = () -> { P.lessonsByDow(dow).remove(old); commit(); };
        form(old == null ? "Новый урок · " + Cal.DOW_FULL[dow] : "Урок · " + Cal.DOW_FULL[dow], f, () -> {
            String nm = name.getText().toString().trim();
            int a = Data.parseHm(st.getText().toString());
            int b = Data.parseHm(en.getText().toString());
            if (nm.isEmpty() || a < 0 || b < 0 || b <= a) {
                toast("Проверь предмет и время (чч:мм)");
                return;
            }
            l.num = num.getText().toString().trim();
            l.name = nm;
            l.start = a;
            l.end = b;
            l.star = star.isChecked();
            if (old == null) P.lessonsByDow(dow).add(l);
            commit();
        }, del);
    }

    void breaksPage(LinearLayout c) {
        backRow(c, "Каникулы");
        for (final Data.Period b : P.breaks) {
            LinearLayout k = card(CARD);
            k.addView(tv(b.name, 16, TEXT, true));
            k.addView(tv(Cal.fmtFull(b.from) + " – " + Cal.fmtFull(b.to), 13, DIM, false));
            k.setOnClickListener(v -> editBreak(b));
            c.addView(k, lp(MP, WC, 0, 0, 0, 8));
        }
        c.addView(chip("+ Добавить каникулы", P.accent, DARK, v -> editBreak(null)), lp(WC, WC, 0, 6, 0, 0));
        c.addView(tv("Весенние и летние даты — ориентир Минпросвещения. Поправь под свою школу.", 12, DIM, false),
                lp(MP, WC, 0, 10, 0, 0));
    }

    void editBreak(final Data.Period old) {
        int today = Cal.today(System.currentTimeMillis());
        final EditText name = input("Название", old == null ? "Каникулы" : old.name, false);
        final EditText from = input("Первый день дд.мм.гггг", Cal.fmtFull(old == null ? today : old.from), false);
        final EditText to = input("Последний день дд.мм.гггг", Cal.fmtFull(old == null ? today + 6 : old.to), false);
        LinearLayout f = vbox();
        f.addView(small("Название")); f.addView(name);
        f.addView(small("Первый день")); f.addView(from);
        f.addView(small("Последний день")); f.addView(to);
        Runnable del = null;
        if (old != null) del = () -> { P.breaks.remove(old); commit(); };
        form(old == null ? "Новые каникулы" : "Каникулы", f, () -> {
            int a = Cal.parse(from.getText().toString());
            int b = Cal.parse(to.getText().toString());
            String nm = name.getText().toString().trim();
            if (nm.isEmpty() || a == Integer.MIN_VALUE || b == Integer.MIN_VALUE || b < a) {
                toast("Проверь название и даты (дд.мм.гггг)");
                return;
            }
            if (old == null) {
                P.breaks.add(new Data.Period(nm, a, b));
            } else {
                old.name = nm; old.from = a; old.to = b;
            }
            commit();
        }, del);
    }

    void holidaysPage(LinearLayout c) {
        backRow(c, "Праздники");
        for (final Data.Holiday h : P.holidays) {
            LinearLayout k = card(CARD);
            k.addView(tv(h.name, 16, TEXT, true));
            k.addView(tv(Cal.DOW_SHORT[Cal.dow(h.day)] + " " + Cal.fmtFull(h.day), 13, DIM, false));
            k.setOnClickListener(v -> editHoliday(h));
            c.addView(k, lp(MP, WC, 0, 0, 0, 8));
        }
        c.addView(chip("+ Добавить выходной", P.accent, DARK, v -> editHoliday(null)), lp(WC, WC, 0, 6, 0, 0));
        c.addView(tv("Указ Крыма о выходных на 2027 (Ураза-байрам, Курбан-байрам) ещё не вышел. Когда выйдет, добавь даты сюда.",
                12, DIM, false), lp(MP, WC, 0, 10, 0, 0));
    }

    void editHoliday(final Data.Holiday old) {
        int today = Cal.today(System.currentTimeMillis());
        final EditText name = input("Название", old == null ? "Выходной" : old.name, false);
        final EditText date = input("Дата дд.мм.гггг", Cal.fmtFull(old == null ? today : old.day), false);
        LinearLayout f = vbox();
        f.addView(small("Название")); f.addView(name);
        f.addView(small("Дата")); f.addView(date);
        Runnable del = null;
        if (old != null) del = () -> { P.holidays.remove(old); commit(); };
        form(old == null ? "Новый выходной" : "Выходной", f, () -> {
            int d = Cal.parse(date.getText().toString());
            String nm = name.getText().toString().trim();
            if (nm.isEmpty() || d == Integer.MIN_VALUE) {
                toast("Проверь название и дату (дд.мм.гггг)");
                return;
            }
            if (old == null) {
                P.holidays.add(new Data.Holiday(d, nm));
            } else {
                old.day = d; old.name = nm;
            }
            commit();
        }, del);
    }
}
